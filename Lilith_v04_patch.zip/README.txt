LILITH VOICE 0.4 - PARCHE PARA EL REPOSITORIO Voice-

1. Sube este ZIP a la raiz de GitHub (sin extraerlo).
2. En Codespaces, terminal en /workspaces/Voice-:
   git pull origin main
   unzip -o Lilith_v04_patch.zip -d /tmp/lilith_v04_patch
   python3 /tmp/lilith_v04_patch/apply_v04.py
3. Revisa los cambios, luego:
   git add app/src/main/AndroidManifest.xml app/build.gradle app/src/main/java/com/lilithvoice/offline/*.java
   git commit -m "Lilith v0.4: voz configurable y apertura confirmada de apps"
   git push origin main
4. Mira Actions, descarga el nuevo artefacto SI la compilacion es verde.

PREFERENCIAS PREDETERMINADAS: voz misteriosa (preferencia de español), tono 1.00, velocidad 1.10, personalidad traviesa.
APERTURA: reconocimiento -> notificacion -> toque para confirmar; no abre apps arbitrariamente desde segundo plano.
Se guardan los ajustes con SharedPreferences. Probar voz: menu de ajustes de la APK.
La sintesis de Android no garantiza genero ni timbre de la voz.

No compartas credenciales ni claves. No se ha probado en telefono real.
