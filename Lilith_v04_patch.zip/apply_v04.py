#!/usr/bin/env python3
"""Apply Lilith 0.4 changes to existing v0.3 GitHub Codespaces checkout."""
from pathlib import Path
import shutil
root=Path.cwd()
base=root/'app/src/main/java/com/lilithvoice/offline'
assert (base/'ListenerService.java').exists() and (base/'MainActivity.java').exists(), 'Ejecuta en /workspaces/Voice- con la v0.3 extraida'
assert 'versionCode 3' in (root/'app/build.gradle').read_text(), 'La base debe ser Lilith v0.3 (versionCode 3)'
patch=Path(__file__).resolve().parent

def modify(path,old,new):
 p=root/path
 txt=p.read_text()
 if old not in txt:
  raise RuntimeError(f'No se ha encontrado el fragmento esperado en {path}: {old[:90]}')
 p.write_text(txt.replace(old,new,1))

# Preserve the previous sources for review in the Codespaces workspace.
for name in ['ListenerService.java','MainActivity.java']:
 shutil.copy2(base/name,base/(name+'.v03.bak'))
for name in ['VoicePrefs.java','VoiceSettingsActivity.java','AppLauncher.java']:
 shutil.copy2(patch/'extra'/name,base/name)

activity='app/src/main/java/com/lilithvoice/offline/MainActivity.java'
modify(activity,'    Button stop=new Button(this);', '''    Button configure=new Button(this);configure.setText("AJUSTES DE VOZ · PRUEBA");layout.addView(configure);
    configure.setOnClickListener(v->startActivity(new Intent(this,VoiceSettingsActivity.class)));
    Button stop=new Button(this);''')
modify(activity,'title.setText("LILITH  ·  v0.3")','title.setText("LILITH  ·  v0.4")')
modify(activity,'"Prueba también: «Qué hora es» o «Abre ChatGPT».\\n\\n"+', '"Prueba también: «Qué hora es» y luego «Abre Spotify».\\n\\n"+')

service='app/src/main/java/com/lilithvoice/offline/ListenerService.java'
modify(service,'    orb=new OrbOverlay(this);','''    nm.createNotificationChannel(new NotificationChannel("lilith_launch","Lilith · Confirmar apertura",NotificationManager.IMPORTANCE_HIGH));
    orb=new OrbOverlay(this);''')
start='''        tts.setLanguage(new Locale("es","ES"));
        // Request a likely feminine Spanish voice when present. The system ultimately decides.
        for(android.speech.tts.Voice v:tts.getVoices()==null?java.util.Collections.<android.speech.tts.Voice>emptySet():tts.getVoices()){
          String name=v.getName().toLowerCase(Locale.ROOT);
          if(v.getLocale().getLanguage().equals("es") && (name.contains("female") || name.contains("mujer") || name.contains("femen"))){tts.setVoice(v);break;}
        }
        tts.setSpeechRate(1.02f);'''
modify(service,start,'        VoicePrefs.configure(this,tts);')
modify(service,'speak((responseIndex++%2==0)?"Dime, cariño. Te escucho.":"Aquí estoy, picha. ¿Qué necesitas?");', '''speak(VoicePrefs.personality(this).equals("neutra") ? "Dime, te escucho." :
          ((responseIndex++%2==0)?"Dime, cariño. Te escucho.":"Aquí estoy, picha. ¿Qué necesitas?"));''')
modify(service,'''        } else if(text.contains("abre chatgpt") || text.contains("abre chat gpt")) {''','''        } else if(text.matches(".*\\\\b(abre|abrir|abre la|abre el)\\\\b.*") || text.startsWith("abre ")) {
          String appName=text.replaceFirst("^.*?\\\\b(?:abre|abrir)\\\\s+(?:la |el )?","").trim();
          if(appName.isEmpty()) speak("¿Qué aplicación quieres abrir?");
          else speak(AppLauncher.offer(this,appName));
        } else if(text.contains("abre chatgpt") || text.contains("abre chat gpt")) {''')
# Note: the original ChatGPT branch remains but is unreachable when the generic open command matches.
modify(service,'''    speaking=true;awakeUntil=System.currentTimeMillis()+14000;''','''    VoicePrefs.configure(this,tts);
    speaking=true;awakeUntil=System.currentTimeMillis()+14000;''')

manifest='app/src/main/AndroidManifest.xml'
modify(manifest,'<queries><package android:name="com.openai.chatgpt"/></queries>', '''<queries>
  <package android:name="com.openai.chatgpt"/>
  <intent><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent>
 </queries>''')
modify(manifest,'  <service android:name=".ListenerService"', '  <activity android:name=".VoiceSettingsActivity" android:exported="false"/>\n  <service android:name=".ListenerService"')
modify('app/build.gradle',"versionCode 3; versionName '0.3'","versionCode 4; versionName '0.4'")
print('Lilith v0.4 aplicada. Revisa git diff y compila. Copias locales .v03.bak creadas.')
