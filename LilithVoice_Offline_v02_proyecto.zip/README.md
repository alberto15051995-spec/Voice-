# Lilith Voice Offline v0.2 (experimental)

**Estado: código fuente listo para intentar compilar; APK no compilada ni validada en dispositivo.**

## Objetivo
Detectar localmente la frase «Oye ChatGPT» en un teléfono Android (Xiaomi 15T Pro/Android 16). No necesita cuenta ni clave. Se usa **Vosk** en lugar de Sherpa-ONNX para esta primera versión, porque hay un modelo español Android pequeño y una dependencia Maven sencilla. No es un detector de wake words dedicado: puede equivocarse, necesita una pausa para reconocer una frase completa, y consume más recursos que Porcupine.

## Generar APK en GitHub
1. Crea un repositorio **privado** y sube el contenido de esta carpeta (no la carpeta contenedora).
2. En el repositorio abre Actions > Compilar Lilith Voice APK > Run workflow.
3. Cuando finalice correctamente, en Artifacts descarga `LilithVoice-Offline-v0.2-debug`.
4. Descomprime el artefacto e instala `app-debug.apk` en tu móvil. Es una versión experimental de depuración.

El workflow descarga el modelo español de https://alphacephei.com/vosk/models/ (Apache 2.0, ~39 MB) **durante la compilación**, lo incorpora al APK y descarga la biblioteca `com.alphacephei:vosk-android:0.3.47` desde Maven Central. Para usarlo sin Internet tras instalar, la primera vez la app copia el modelo del APK al almacenamiento interno. Esa primera inicialización puede tardar.

## Uso
1. Instala ChatGPT oficial y Lilith Voice.
2. Abre Lilith Voice desbloqueado y concede acceso al micrófono y a las notificaciones.
3. Pulsa ACTIVAR ESCUCHA y espera a que la notificación diga 'Escuchando'.
4. Pronuncia 'Oye ChatGPT', haz una pequeña pausa y observa si aparece la notificación de detección.
5. Toca la notificación para abrir ChatGPT. Android puede requerir desbloquear el teléfono. La app NO garantiza abrir el modo voz directamente.
6. Para parar, usa DETENER ESCUCHA o la acción de la notificación permanente.

## Limitaciones
- Android 14+ impide arrancar libremente servicios con micrófono desde segundo plano: **activa el servicio con la app visible, antes de bloquear la pantalla**. No se inicia solo al reiniciar.
- En HyperOS puede ser necesario permitir segundo plano y quitar las restricciones de batería. Puede cerrarse igualmente.
- Se mantiene una notificación persistente durante la escucha; el micrófono está activo. Audio procesado localmente, sin envío de grabaciones.
- La API de ChatGPT no ofrece aquí un método público documentado para iniciar por fuerza una sesión de voz desde otra app.
- La frase exacta puede fallar por la forma de transcribir 'ChatGPT' (por ejemplo 'chat ge pe te'). Código abierto para ajustar variantes.
- **No está probado ni compilado en este entorno**. Puede requerir correcciones al ejecutar GitHub Actions o probarlo en el Xiaomi.

## Licencias
Código de este proyecto: MIT. Vosk Android / modelo pequeño de español: consulta las licencias en https://alphacephei.com/vosk/models/ y https://github.com/alphacep/vosk-api .
